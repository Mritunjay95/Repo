package com.hc.shares;

public class FileModel {
	
	private String stock; 
	private String time;
	private String price;
	private String shares;
	/**
	 * @return the stock
	 */
	public String getStock() {
		return stock;
	}
	/**
	 * @param stock the stock to set
	 */
	public void setStock(String stock) {
		this.stock = stock;
	}
	/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}
	/**
	 * @return the price
	 */
	public String getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(String price) {
		this.price = price;
	}
	/**
	 * @return the shares
	 */
	public String getShares() {
		return shares;
	}
	/**
	 * @param shares the shares to set
	 */
	public void setShares(String shares) {
		this.shares = shares;
	}

	
}
