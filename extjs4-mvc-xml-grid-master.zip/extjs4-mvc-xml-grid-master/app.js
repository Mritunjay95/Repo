Ext.application({
    name: 'ExtMVC',

    controllers: [
        'Books'
    ],

    autoCreateViewport: true
});