package com.hc.shares;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;



public class FileMapper implements FieldSetMapper<FileModel>{

	public FileModel mapFieldSet(FieldSet fieldSet) throws BindException {
		
		FileModel fileModel = new FileModel();
		fileModel.setPrice(fieldSet.readString(0));
		fileModel.setShares(fieldSet.readString(1));
		fileModel.setStock(fieldSet.readString(2));
		fileModel.setTime(fieldSet.readString(3));
		return fileModel;
	}

}
